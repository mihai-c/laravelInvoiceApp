-- MySQL dump 10.15  Distrib 10.0.37-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: alaskan_laravel
-- ------------------------------------------------------
-- Server version	10.0.37-MariaDB-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cif` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attr_fiscal` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reg` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judet` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banca` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_user_id_foreign` (`user_id`),
  CONSTRAINT `clients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (4,'AKN-C.','S.C. Alaskan Global Network S.R.L.','36086038',NULL,'J40/6938/2016','B-dul Basarabia, 256g, București, Sect 3','Municipiul București','B-dul Basarabia, 256g, București, Sect 3',NULL,'Mihai Iorga','0740847048',NULL,'Romania','RO53INGB0000999905930828','ING Bank','s_c_alaskan_global_network_s_r_l_.jpg',1,'2018-08-01 08:02:48','2018-08-01 15:13:57');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_cont`
--

DROP TABLE IF EXISTS `config_cont`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_cont` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iban` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banca` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `moneda` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `swift` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_cont`
--

LOCK TABLES `config_cont` WRITE;
/*!40000 ALTER TABLE `config_cont` DISABLE KEYS */;
INSERT INTO `config_cont` VALUES (9,'RO91INGB0000999906889474','ING Bank','RON',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `config_cont` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_docs`
--

DROP TABLE IF EXISTS `config_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_docs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tip_document` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serie_document` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numar_document` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descriere` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_document` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_docs`
--

LOCK TABLES `config_docs` WRITE;
/*!40000 ALTER TABLE `config_docs` DISABLE KEYS */;
INSERT INTO `config_docs` VALUES (9,'factura','AGN','00001',NULL,1,'2018-08-06 08:40:49','2018-08-06 08:40:49'),(11,'chitanta','CAGN','00001',NULL,1,'2018-08-06 08:49:44','2018-08-06 08:49:44'),(12,'proforma','AKN','00001',NULL,1,'2018-08-06 08:57:48','2018-08-06 08:57:48'),(13,'factura','AKN','10001',NULL,0,'2018-08-21 14:23:13','2018-08-21 14:23:13');
/*!40000 ALTER TABLE `config_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_vat`
--

DROP TABLE IF EXISTS `config_vat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_vat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_procent` decimal(5,2) NOT NULL,
  `default_vat` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_vat`
--

LOCK TABLES `config_vat` WRITE;
/*!40000 ALTER TABLE `config_vat` DISABLE KEYS */;
INSERT INTO `config_vat` VALUES (8,'Normala',19.00,0,'2018-08-06 10:02:39','2018-08-06 10:02:39'),(9,'TVA inclus',0.00,1,'2018-08-06 10:02:44','2018-08-06 10:02:44'),(10,'SFDD',0.00,0,'2018-08-06 10:02:50','2018-08-06 10:02:50');
/*!40000 ALTER TABLE `config_vat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_config`
--

DROP TABLE IF EXISTS `core_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `config_key` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_config`
--

LOCK TABLES `core_config` WRITE;
/*!40000 ALTER TABLE `core_config` DISABLE KEYS */;
INSERT INTO `core_config` VALUES (1,'company','Alaskan Global Network SRL','2018-07-31 21:00:00','2018-08-02 15:33:42'),(2,'cif','36086038','2018-07-31 21:00:00','2018-08-02 15:33:42'),(3,'reg','J40/6938/2017','2018-07-31 21:00:00','2018-08-02 15:33:42'),(4,'address','Bd. Basarabia Nr.256G Biroul 7.1 B, Et.7','2018-07-31 21:00:00','2018-08-02 15:33:42'),(5,'city','Sector 3','2018-07-31 21:00:00','2018-08-02 15:33:42'),(6,'judet','Bucuresti','2018-07-31 21:00:00','2018-08-02 15:33:42'),(7,'iban','RO91INGB0000999906889474','2018-07-31 21:00:00','2018-08-02 15:33:42'),(8,'banca','ING Bank','2018-07-31 21:00:00','2018-08-02 15:33:42'),(9,'email','office@alaskan.ro','2018-07-31 21:00:00','2018-08-02 15:33:42'),(10,'capital','200.00','2018-07-31 21:00:00','2018-08-02 15:33:42'),(11,'web','www.alaskan.ro','2018-07-31 21:00:00','2018-08-02 15:33:42'),(12,'logo','alaskan_global_network_srl.jpg','2018-07-31 21:00:00','2018-08-02 15:33:42'),(13,'ask_pass_on_change','','2018-07-31 21:00:00','2018-07-31 21:00:00'),(14,'client_code','AKN-C.','2018-07-31 21:00:00','2018-07-31 21:00:00');
/*!40000 ALTER TABLE `core_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `file_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_product_id_foreign` (`product_id`),
  CONSTRAINT `galleries_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` VALUES (1,1,'15345436644879.png','2018-08-17 19:07:45','2018-08-17 19:07:45'),(2,1,'15345436654747.png','2018-08-17 19:07:45','2018-08-17 19:07:45'),(3,1,'15345436653498.png','2018-08-17 19:07:45','2018-08-17 19:07:45'),(25,2,'15347641418804.png','2018-08-20 08:22:21','2018-08-20 08:22:21'),(26,2,'15347641427671.png','2018-08-20 08:22:22','2018-08-20 08:22:22'),(32,2,'15347659444205.png','2018-08-20 08:52:24','2018-08-20 08:52:24'),(34,2,'15347663659965.png','2018-08-20 08:59:25','2018-08-20 08:59:25'),(38,2,'15347673252618.png','2018-08-20 09:15:25','2018-08-20 09:15:25'),(39,1,'15347674831009.png','2018-08-20 09:18:03','2018-08-20 09:18:03'),(42,1,'15347680531170.png','2018-08-20 09:27:33','2018-08-20 09:27:33');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_serial` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_number` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_total` decimal(12,2) NOT NULL,
  `invoice_currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exchange_rate` decimal(6,4) DEFAULT NULL,
  `invoice_comments` text COLLATE utf8mb4_unicode_ci,
  `invoice_notes` text COLLATE utf8mb4_unicode_ci,
  `invoice_date` int(11) NOT NULL,
  `payment_date` int(11) DEFAULT NULL,
  `invoice_status` int(11) NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `client_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_cif` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_reg` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_iban` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_banca` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_address` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_judet` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_city` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_zip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_issuer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_delegat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delegat_cnp` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delegat_ci` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_shipping_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_car` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_on` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_at` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoices_client_id_foreign` (`client_id`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,'AGN','00001',46.32,'RON',NULL,NULL,NULL,NULL,56447,NULL,1,4,'Alaskan Global Network SRL','434',NULL,'4334',NULL,'Adresa','Judet','City','zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2018-08-14 21:00:00','2018-08-14 21:00:00'),(2,'AGN','00002',46.32,'RON',NULL,NULL,NULL,NULL,56447,NULL,1,4,'Alaskan Global Network SRL','434',NULL,'4334',NULL,'Adresa','Judet','City','zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2018-08-14 21:00:00','2018-08-14 21:00:00'),(3,'AKN','10001',46.32,'RON',NULL,NULL,NULL,NULL,56447,NULL,1,4,'Alaskan Global Network SRL','434',NULL,'4334',NULL,'Adresa','Judet','City','zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2018-08-14 21:00:00','2018-08-14 21:00:00');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(4,'2018_07_31_103946_create_clients_table',3),(5,'2018_08_01_182725_create_table_core_config',4),(6,'2018_08_01_195324_create_table_config_docs',5),(7,'2018_08_01_195935_create_table_config_vat',5),(8,'2018_08_01_200156_create_table_config_cont',5),(10,'2018_08_06_161606_create_invoices_table',6),(11,'2018_08_15_093322_create_products_table',7),(12,'2018_08_17_112422_create_galleries_table',8);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `client_price` decimal(10,2) DEFAULT NULL,
  `weight` decimal(10,3) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `product_um` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `default_img` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_client_id_foreign` (`client_id`),
  CONSTRAINT `products_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'AKN00001','Produs test',1200.00,NULL,0.500,'RON','Descriere Test','buc',NULL,'15345436654747.png','2018-08-15 07:56:35','2018-08-22 09:31:06'),(2,'0000234','Test22',12.35,NULL,0.356,'EUR','Descriere produs','Buc',NULL,'15347641418804.png','2018-08-16 07:24:42','2018-08-22 09:09:19');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Mihai Iorga','mihai.iorga@alaskan.ro','$2y$10$lL25Ii6hzlmnNGpF3PHnzOZnTReuooQ9MiGTjPCChAsvkbJaTP9dS','I0kZfIVcjQSNe0m5WkDp3LenXFw7KwkkHnI97tXRGlW7IMAr6aryz7VRDJBE','2018-07-04 08:46:55','2018-08-02 08:41:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'alaskan_laravel'
--

--
-- Dumping routines for database 'alaskan_laravel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-01  0:00:56
